# Dashboard Data Regeneration Report

Generated: 2026-04-28T21:20:28.816640+00:00

## Source

- Server: `aws-luckyus-icyberdata-rw` (via mcp-db-gateway)
- Database: `luckyus_icyberdata`
- Snapshot timestamp: `2026-04-28 18:08 UTC`

## Layer Counts (Live from CyberData)

| Layer | Count | Storage (GB) |
|-------|-------|--------------|
| ODS | 1011 | 19.98 |
| DWD | 126 | 63.54 |
| DWS | 55 | 10.4 |
| DIM | 46 | 10.39 |
| ADS | 130 | 15.09 |
| OTHER | 109 | 2.05 |

## Generated Inventory

- DIM_TABLES: 46
- DWD_TABLES: 126
- DWS_TABLES: 55
- ADS_TABLES: 126
- ODS_TABLES: 267
- **Total**: 620

## Lineage Coverage

- LINEAGE_MAP entries: **481**
- Total upstream edges: 858
- Total downstream edges: 859

## Sample Verifications (云飞's Test Cases)

| Table | In Inventory | Has Lineage |
|-------|--------------|-------------|
| `dwd_mg_order_first_detail_d_his` | ✅ | ✅ |
| `dwd_t_ord_order_d_inc` | ✅ | ✅ |
| `dwd_t_ord_order_item_d_inc` | ✅ | ✅ |
| `dim_user_base_info_d_his` | ✅ | ✅ |
| `dim_shop_d_his` | ✅ | ✅ |
| `dws_mg_user_order_static_d_his` | ✅ | ✅ |
| `dws_mg_log_user_event_d_1d` | ✅ | ✅ |
| `ads_opt_t_cloud_chart_shop_d_inc` | ✅ | ✅ |
| `ads_opt_t_cloud_chart_shop_spu_10min_d_inc` | ✅ | ✅ |
| `ads_mkt_t_operational_report_w_inc` | ✅ | ✅ |

## Reproducibility

Re-run the regeneration with: `python3 scripts/regenerate_data.py`
To re-extract from CyberData (requires pymysql):
  Set `CYBERDATA_HOST`, `CYBERDATA_USER`, `CYBERDATA_PASSWORD` env vars,
  then run with `--from-db` (TODO: implement direct DB pull).
