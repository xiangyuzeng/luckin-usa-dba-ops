'use client';

import { useState, useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import {
  COLORS, LAYER_COLORS, TABS, SIDEBAR_BUTTONS, LAYER_DEFINITIONS,
  TABLE_COUNT_DONUT, STORAGE_DONUT, COMPUTE_DONUT,
  LAYER_CARDS, ODS_SOURCES,
  LINEAGE_QUICK_SELECT, LINEAGE_MAP, LINEAGE_STATS,
  ENUM_FIELDS, RISK_SECTIONS, CYBERDATA_OVERVIEW,
  DIM_TABLES, DWD_TABLES, DWS_TABLES, ADS_TABLES, ODS_TABLES,
} from './data';

// =============================================================================
// Style Constants
// =============================================================================
const styles = {
  card: {
    background: COLORS.card,
    borderRadius: '12px',
    border: `1px solid ${COLORS.border}`,
    boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
    padding: '20px',
  },
  header: {
    background: `linear-gradient(135deg, ${COLORS.navy} 0%, ${COLORS.primary} 100%)`,
    color: '#fff',
    padding: '20px 32px',
  },
  tabBar: {
    display: 'flex',
    gap: '4px',
    padding: '8px',
    background: '#F1F3F5',
    borderRadius: '10px',
    margin: '16px 32px',
  },
  tab: (active) => ({
    padding: '10px 24px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: active ? 600 : 400,
    background: active ? '#fff' : 'transparent',
    color: active ? COLORS.text : COLORS.muted,
    boxShadow: active ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
    transition: 'all 0.2s',
    fontFamily: 'inherit',
  }),
  tableHeader: {
    background: COLORS.navy,
    color: '#fff',
    padding: '10px 14px',
    fontSize: '13px',
    fontWeight: 500,
    textAlign: 'left',
    whiteSpace: 'nowrap',
    position: 'sticky',
    top: 0,
    zIndex: 1,
  },
  tableCell: (isAlt, isHover) => ({
    padding: '10px 14px',
    fontSize: '13px',
    borderBottom: `1px solid ${COLORS.border}`,
    background: isHover ? COLORS.hoverRow : (isAlt ? COLORS.rowAlt : '#fff'),
    cursor: 'pointer',
    transition: 'background 0.15s',
  }),
  mono: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: '13px',
  },
  badge: (color) => ({
    display: 'inline-block',
    padding: '2px 10px',
    borderRadius: '12px',
    fontSize: '12px',
    fontWeight: 600,
    color: '#fff',
    background: color,
  }),
  layerBadge: (layer) => ({
    display: 'inline-block',
    padding: '2px 8px',
    borderRadius: '4px',
    fontSize: '11px',
    fontWeight: 600,
    color: '#fff',
    background: LAYER_COLORS[layer] || COLORS.muted,
  }),
};

// =============================================================================
// Donut Chart Component
// =============================================================================
function DonutChart({ data, centerLabel, centerValue, size = 200, labels = [] }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
      <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius={size * 0.3}
              outerRadius={size * 0.45}
              paddingAngle={2}
              stroke="none"
            >
              {data.map((entry, i) => (
                <Cell key={i} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value) => value.toLocaleString()}
              contentStyle={{ borderRadius: '8px', border: `1px solid ${COLORS.border}`, fontSize: '13px' }}
            />
          </PieChart>
        </ResponsiveContainer>
        {/* Center label */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          textAlign: 'center',
          pointerEvents: 'none',
        }}>
          <div style={{ fontSize: '12px', color: COLORS.muted }}>{centerLabel}</div>
          <div style={{ fontSize: '22px', fontWeight: 700, color: COLORS.text, fontFamily: "'JetBrains Mono', monospace" }}>
            {centerValue}
          </div>
        </div>
      </div>
      {/* Labels to the right of the donut */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {labels.map((l, i) => (
          <div key={i} style={{
            fontSize: '13px',
            color: COLORS.text,
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            fontWeight: 500,
          }}>
            <span style={{
              width: '10px', height: '10px', borderRadius: '50%',
              background: data[i]?.color || COLORS.muted,
              display: 'inline-block', flexShrink: 0,
            }} />
            {l}
          </div>
        ))}
      </div>
    </div>
  );
}

// =============================================================================
// Pagination Component
// =============================================================================
function Pagination({ total, page, pageSize, onChange }) {
  const totalPages = Math.ceil(total / pageSize);
  if (totalPages <= 1) return null;

  const pages = [];
  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || (i >= page - 1 && i <= page + 1)) {
      pages.push(i);
    } else if (pages[pages.length - 1] !== '...') {
      pages.push('...');
    }
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', padding: '16px 0' }}>
      <button
        onClick={() => onChange(Math.max(1, page - 1))}
        disabled={page === 1}
        style={{
          padding: '6px 12px', borderRadius: '6px', border: `1px solid ${COLORS.border}`,
          background: '#fff', cursor: page === 1 ? 'default' : 'pointer', fontSize: '13px',
          color: page === 1 ? COLORS.border : COLORS.text, fontFamily: 'inherit',
        }}
      >
        上一页
      </button>
      {pages.map((p, i) => (
        <button
          key={i}
          onClick={() => typeof p === 'number' && onChange(p)}
          style={{
            padding: '6px 12px', borderRadius: '6px', fontSize: '13px', fontFamily: 'inherit',
            border: p === page ? `1px solid ${COLORS.primary}` : `1px solid ${COLORS.border}`,
            background: p === page ? COLORS.primary : '#fff',
            color: p === page ? '#fff' : (typeof p === 'number' ? COLORS.text : COLORS.muted),
            cursor: typeof p === 'number' ? 'pointer' : 'default',
          }}
        >
          {p}
        </button>
      ))}
      <button
        onClick={() => onChange(Math.min(totalPages, page + 1))}
        disabled={page === totalPages}
        style={{
          padding: '6px 12px', borderRadius: '6px', border: `1px solid ${COLORS.border}`,
          background: '#fff', cursor: page === totalPages ? 'default' : 'pointer', fontSize: '13px',
          color: page === totalPages ? COLORS.border : COLORS.text, fontFamily: 'inherit',
        }}
      >
        下一页
      </button>
      <span style={{ fontSize: '12px', color: COLORS.muted, marginLeft: '8px' }}>
        共 {total} 条 / {totalPages} 页
      </span>
    </div>
  );
}

// =============================================================================
// Risk Card Component
// =============================================================================
function RiskCard({ risk, expanded, onToggle }) {
  const severityMap = {
    high: { color: COLORS.red, label: '高风险', bg: '#FEF2F2' },
    medium: { color: COLORS.orange, label: '中风险', bg: '#FFFBEB' },
    low: { color: COLORS.green, label: '低风险', bg: '#F0FDF4' },
  };
  const sev = severityMap[risk.severity] || severityMap.medium;

  return (
    <div style={{
      ...styles.card,
      borderLeft: `4px solid ${sev.color}`,
      marginBottom: '12px',
      padding: '0',
      overflow: 'hidden',
    }}>
      <div
        onClick={() => onToggle(risk.id)}
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '16px 20px', cursor: 'pointer', userSelect: 'none',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span style={styles.badge(sev.color)}>{sev.label}</span>
          <span style={{ fontWeight: 600, fontSize: '15px', color: COLORS.text }}>{risk.title}</span>
          <span style={{
            background: '#F3F4F6', borderRadius: '12px', padding: '2px 10px',
            fontSize: '12px', color: COLORS.muted, fontFamily: "'JetBrains Mono', monospace",
          }}>
            {risk.count}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span style={{ fontSize: '13px', color: COLORS.muted }}>{risk.description}</span>
          <span style={{
            transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)',
            transition: 'transform 0.2s',
            fontSize: '14px',
            color: COLORS.muted,
          }}>
            &#9660;
          </span>
        </div>
      </div>
      <div style={{
        maxHeight: expanded ? '2000px' : '0',
        overflow: 'hidden',
        transition: 'max-height 0.3s ease',
      }}>
        <div style={{ padding: '0 20px 20px', background: '#F9FAFB' }}>
          <RiskDetails risk={risk} />
        </div>
      </div>
    </div>
  );
}

// =============================================================================
// Risk Details (expanded content)
// =============================================================================
function RiskDetails({ risk }) {
  if (risk.id === 'inactive-tables') {
    return (
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            {['表名', '数据库', '最后更新', '原因'].map(h => (
              <th key={h} style={styles.tableHeader}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {risk.details.map((d, i) => (
            <tr key={i}>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono }}>{d.table}</td>
              <td style={styles.tableCell(i % 2 === 1, false)}>{d.db}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono }}>{d.lastUpdate}</td>
              <td style={styles.tableCell(i % 2 === 1, false)}>{d.reason}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  }

  if (risk.id === 'storage-top') {
    return (
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            {['排名', '表名', '数据库', '存储(GB)', '占比'].map(h => (
              <th key={h} style={styles.tableHeader}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {risk.details.map((d, i) => (
            <tr key={i}>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), fontWeight: 600, textAlign: 'center' }}>{i + 1}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono }}>{d.table}</td>
              <td style={styles.tableCell(i % 2 === 1, false)}>{d.db}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, textAlign: 'right' }}>{d.sizeGB}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), textAlign: 'right' }}>{d.pct}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  }

  if (risk.id === 'compute-top') {
    return (
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            {['排名', '表名', '数据库', '日均DPU', '平均耗时(min)'].map(h => (
              <th key={h} style={styles.tableHeader}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {risk.details.map((d, i) => (
            <tr key={i}>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), fontWeight: 600, textAlign: 'center' }}>{i + 1}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono }}>{d.table}</td>
              <td style={styles.tableCell(i % 2 === 1, false)}>{d.db}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, textAlign: 'right' }}>{d.dailyDPU}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, textAlign: 'right' }}>{d.avgMinutes}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  }

  if (risk.id === 'circular-ref') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {risk.details.map((d, i) => (
          <div key={i} style={{
            ...styles.card, padding: '14px', borderLeft: `3px solid ${COLORS.red}`,
            background: '#FEF2F2',
          }}>
            <div style={{ ...styles.mono, fontSize: '12px', color: COLORS.text, wordBreak: 'break-all', marginBottom: '8px' }}>
              {d.chain}
            </div>
            <div style={{ fontSize: '13px', color: COLORS.muted }}>{d.impact}</div>
          </div>
        ))}
      </div>
    );
  }

  if (risk.id === 'invalid-ref') {
    return (
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            {['引用表', '被引用表(无效)', '原因'].map(h => (
              <th key={h} style={styles.tableHeader}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {risk.details.map((d, i) => (
            <tr key={i}>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono }}>{d.table}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, color: COLORS.red }}>{d.ref}</td>
              <td style={styles.tableCell(i % 2 === 1, false)}>{d.reason}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  }

  if (risk.id === 'deep-lineage') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {risk.details.map((d, i) => (
          <div key={i} style={{ ...styles.card, padding: '14px', borderLeft: `3px solid ${COLORS.orange}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <span style={{ ...styles.mono, fontWeight: 600 }}>{d.table}</span>
              <span style={styles.badge(COLORS.orange)}>深度 {d.depth}</span>
            </div>
            <div style={{ ...styles.mono, fontSize: '12px', color: COLORS.muted, wordBreak: 'break-all' }}>
              {d.chain}
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (risk.id === 'enum-conflict') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {risk.details.map((d, i) => (
          <div key={i} style={{ ...styles.card, padding: '16px' }}>
            <div style={{ fontWeight: 600, fontSize: '14px', marginBottom: '10px', color: COLORS.text }}>
              字段: <span style={styles.mono}>{d.field}</span>
            </div>
            {d.conflicts.map((c, j) => (
              <div key={j} style={{
                padding: '10px 14px', borderRadius: '8px', marginBottom: '8px',
                background: j === 0 ? '#FEF2F2' : COLORS.yellowBg,
                border: `1px solid ${j === 0 ? '#FECACA' : COLORS.yellowBorder}`,
              }}>
                <div style={{ fontSize: '12px', color: COLORS.muted, marginBottom: '4px' }}>{c.context}</div>
                <div style={{ ...styles.mono, fontSize: '13px' }}>{c.definition}</div>
              </div>
            ))}
            <div style={{
              fontSize: '13px', color: COLORS.red, fontWeight: 500,
              padding: '8px 12px', background: '#FEF2F2', borderRadius: '6px', marginTop: '4px',
            }}>
              影响: {d.impact}
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (risk.id === 'field-weight') {
    return (
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            {['排名', '字段名', '引用表数', '引用表'].map(h => (
              <th key={h} style={styles.tableHeader}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {risk.details.map((d, i) => (
            <tr key={i}>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), fontWeight: 600, textAlign: 'center' }}>{i + 1}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono }}>{d.field}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, textAlign: 'center' }}>{d.tableCount}</td>
              <td style={{ ...styles.tableCell(i % 2 === 1, false), fontSize: '12px', color: COLORS.muted }}>{d.tables}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  }

  return null;
}

// =============================================================================
// Lineage Node Component
// =============================================================================
function LineageNode({ table, layer, db, highlighted, refType }) {
  return (
    <div style={{
      padding: '8px 12px',
      borderRadius: '8px',
      border: `1px solid ${highlighted ? COLORS.primary : COLORS.border}`,
      borderLeft: `3px solid ${LAYER_COLORS[layer] || COLORS.muted}`,
      background: highlighted ? COLORS.hoverRow : '#fff',
      minWidth: '180px',
      maxWidth: '300px',
    }}>
      <div style={{ ...styles.mono, fontSize: '12px', fontWeight: 500, color: COLORS.text, wordBreak: 'break-all' }}>
        {table}
        {refType && (
          <span style={{
            fontSize: '10px', padding: '1px 6px', borderRadius: '4px',
            background: refType === 'JOIN' ? '#DBEAFE' : '#F3E8FF',
            color: refType === 'JOIN' ? '#1D4ED8' : '#7C3AED',
            marginLeft: '4px',
          }}>{refType}</span>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px' }}>
        <span style={styles.layerBadge(layer)}>{layer}</span>
        <span style={{ fontSize: '11px', color: COLORS.muted }}>{db}</span>
      </div>
    </div>
  );
}

// =============================================================================
// Main Dashboard Component
// =============================================================================
export default function Dashboard() {
  // -- Navigation state --
  const [activeTab, setActiveTab] = useState('overview');
  const [sidebarActive, setSidebarActive] = useState('overview-main');

  // -- Screen 2: Lineage state --
  const [lineageSearch, setLineageSearch] = useState('');
  const [lineageSelected, setLineageSelected] = useState(null);
  const [lineageDirection, setLineageDirection] = useState('all');
  const [lineageFormat, setLineageFormat] = useState('graph');
  const [showSuggestions, setShowSuggestions] = useState(false);

  // -- Screen 3: Enum state --
  const [enumSubTab, setEnumSubTab] = useState('category');
  const [enumSearch, setEnumSearch] = useState('');
  const [enumPage, setEnumPage] = useState(1);
  const [selectedField, setSelectedField] = useState(null);

  // -- Screen 4: Risk state --
  const [expandedRisks, setExpandedRisks] = useState({});

  // -- Table hover state --
  const [hoveredRow, setHoveredRow] = useState(null);

  // -- Verify-table search state (top of page) --
  const [verifyQuery, setVerifyQuery] = useState('');

  const PAGE_SIZE = 10;

  // Filtered enum fields
  const filteredEnums = useMemo(() => {
    let result = ENUM_FIELDS;
    if (enumSearch) {
      const q = enumSearch.toLowerCase();
      result = result.filter(f =>
        f.fieldName.toLowerCase().includes(q) ||
        f.description.includes(q) ||
        f.values.toLowerCase().includes(q) ||
        f.tables.some(t => t.toLowerCase().includes(q))
      );
    }
    return result;
  }, [enumSearch]);

  // Grouped enum fields by fieldName (for category view)
  const groupedEnums = useMemo(() => {
    const groups = {};
    ENUM_FIELDS.forEach(f => {
      if (!groups[f.fieldName]) {
        groups[f.fieldName] = { ...f, allTables: [...f.tables] };
      } else {
        groups[f.fieldName].allTables.push(...f.tables);
      }
    });
    return Object.values(groups);
  }, []);

  const pagedEnums = filteredEnums.slice((enumPage - 1) * PAGE_SIZE, enumPage * PAGE_SIZE);

  // Filtered grouped enums (for category sub-tab search)
  const filteredGroupedEnums = useMemo(() => {
    if (!enumSearch) return groupedEnums;
    const q = enumSearch.toLowerCase();
    return groupedEnums.filter(f =>
      f.fieldName.toLowerCase().includes(q) ||
      f.description.includes(q) ||
      f.values.toLowerCase().includes(q) ||
      f.allTables.some(t => t.toLowerCase().includes(q))
    );
  }, [enumSearch, groupedEnums]);

  // Lineage incremental search suggestions
  const allTableNames = useMemo(() => {
    const names = new Set();
    [DIM_TABLES, DWD_TABLES, DWS_TABLES, ADS_TABLES, ODS_TABLES].forEach(arr =>
      arr.forEach(t => names.add(t.name))
    );
    Object.keys(LINEAGE_MAP).forEach(k => names.add(k));
    return [...names].sort();
  }, []);

  const lineageSuggestions = useMemo(() => {
    if (!lineageSearch || lineageSearch.length < 2) return [];
    const q = lineageSearch.toLowerCase();
    return allTableNames.filter(k => k.toLowerCase().includes(q)).slice(0, 20);
  }, [lineageSearch, allTableNames]);

  // Verify-table lookup — returns {found, layer, db, hasLineage} or null
  const verifyResult = useMemo(() => {
    if (!verifyQuery || verifyQuery.length < 2) return null;
    const q = verifyQuery.toLowerCase().trim();
    const arrays = { DIM: DIM_TABLES, DWD: DWD_TABLES, DWS: DWS_TABLES, ADS: ADS_TABLES, ODS: ODS_TABLES };
    let exact = null;
    const partial = [];
    for (const [layer, arr] of Object.entries(arrays)) {
      for (const t of arr) {
        const n = t.name.toLowerCase();
        if (n === q) { exact = { name: t.name, nameZh: t.nameZh, layer, db: t.db, hasLineage: !!LINEAGE_MAP[t.name] }; break; }
        if (n.includes(q)) partial.push({ name: t.name, nameZh: t.nameZh, layer, db: t.db, hasLineage: !!LINEAGE_MAP[t.name] });
      }
      if (exact) break;
    }
    if (exact) return { mode: 'exact', match: exact };
    if (partial.length > 0) return { mode: 'partial', matches: partial.slice(0, 8) };
    return { mode: 'none' };
  }, [verifyQuery]);

  // Coverage stats per layer
  const coverageStats = useMemo(() => {
    const layers = ['DIM', 'DWD', 'DWS', 'ADS', 'ODS'];
    const arrays = { DIM: DIM_TABLES, DWD: DWD_TABLES, DWS: DWS_TABLES, ADS: ADS_TABLES, ODS: ODS_TABLES };
    return layers.map(layer => {
      const total = arrays[layer].length;
      const mapped = arrays[layer].filter(t => !!LINEAGE_MAP[t.name]).length;
      return { layer, mapped, total, pct: total > 0 ? Math.round((mapped / total) * 100) : 0 };
    });
  }, []);

  // Handle sidebar click — stay on overview tab, switch content via sidebarActive
  const handleSidebarClick = (id) => {
    setSidebarActive(id);
  };

  // Handle tab change
  const handleTabChange = (id) => {
    setActiveTab(id);
    setSidebarActive('overview-main');
  };

  // Handle lineage search
  const handleLineageSearch = (value) => {
    setLineageSearch(value);
    if (value && allTableNames.includes(value)) {
      setLineageSelected(value);
    } else if (value === '') {
      setLineageSelected(null);
    }
  };

  // Toggle risk card expansion
  const toggleRisk = (id) => {
    setExpandedRisks(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // =========================================================================
  // Screen 1: Overview
  // =========================================================================
  const renderOverview = () => (
    <div style={{ display: 'flex', gap: '24px' }}>
      {/* Left Sidebar */}
      <div style={{ width: '160px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {SIDEBAR_BUTTONS.map(btn => {
          const isActive = sidebarActive === btn.id;
          return (
            <button
              key={btn.id}
              onClick={() => handleSidebarClick(btn.id)}
              style={{
                padding: '14px 16px',
                borderRadius: '10px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: 600,
                fontFamily: 'inherit',
                background: isActive ? btn.color : `${btn.color}15`,
                color: isActive ? '#fff' : btn.color,
                transition: 'all 0.2s',
                textAlign: 'center',
              }}
            >
              {btn.label}
            </button>
          );
        })}
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '24px' }}>
        {sidebarActive === 'lineage-sub' && renderLineage()}
        {sidebarActive === 'enum-sub' && renderEnum()}
        {sidebarActive === 'overview-main' && (<>
        {/* Row 1: Donut Charts */}
        <div style={{ ...styles.card }}>
          <h3 style={{ fontSize: '16px', fontWeight: 600, color: COLORS.text, marginBottom: '20px' }}>
            基础数据
          </h3>
          <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'flex-start', flexWrap: 'wrap', gap: '24px' }}>
            {/* 库表数量 donut + side labels */}
            <div>
              <div style={{ fontSize: '14px', fontWeight: 600, color: COLORS.text, marginBottom: '8px' }}>库表数量</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                <DonutChart data={TABLE_COUNT_DONUT} centerLabel="库表/数量" centerValue={CYBERDATA_OVERVIEW.totalTables.toLocaleString()} size={180} labels={[]} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div style={{ fontSize: '14px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#8B5CF6', display: 'inline-block' }} />ODS: {TABLE_COUNT_DONUT[0].value}
                  </div>
                  <div style={{ fontSize: '14px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#0365C0', display: 'inline-block' }} />中间层: {TABLE_COUNT_DONUT[1].value}
                  </div>
                  <div style={{ fontSize: '14px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#DC2626', display: 'inline-block' }} />业务层: {TABLE_COUNT_DONUT[2].value}
                  </div>
                </div>
              </div>
            </div>
            {/* 存储资源用量 donut + side labels */}
            <div>
              <div style={{ fontSize: '14px', fontWeight: 600, color: COLORS.text, marginBottom: '8px' }}>存储资源用量</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                <DonutChart data={STORAGE_DONUT} centerLabel="已用65%" centerValue={CYBERDATA_OVERVIEW.totalStorage} size={180} labels={[]} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <div style={{ fontSize: '16px', fontWeight: 700 }}>总量: {CYBERDATA_OVERVIEW.totalStorage}</div>
                  <div style={{ fontSize: '14px', color: COLORS.muted }}>已用 65%</div>
                  <div style={{ fontSize: '12px', color: COLORS.muted }}>分配: ~160 GB</div>
                </div>
              </div>
            </div>
            {/* 计算资源用量 donut + side labels */}
            <div>
              <div style={{ fontSize: '14px', fontWeight: 600, color: COLORS.text, marginBottom: '8px' }}>计算资源用量</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                <DonutChart data={COMPUTE_DONUT} centerLabel="日均MIX" centerValue="56%" size={180} labels={[]} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <div style={{ fontSize: '16px', fontWeight: 700 }}>日均: 56%</div>
                  <div style={{ fontSize: '14px', color: COLORS.muted }}>峰值 &gt;90%: 2.3h</div>
                  <div style={{ fontSize: '12px', color: COLORS.muted, fontStyle: 'italic' }}>暂无实时数据源</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Row 2: Layer Breakdown Cards */}
        <div>
          <h3 style={{ fontSize: '16px', fontWeight: 600, color: COLORS.text, marginBottom: '12px' }}>
            大数据库表分布拆解
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
            {LAYER_CARDS.map(lc => (
              <div key={lc.layer} style={{
                ...styles.card,
                borderTop: `3px solid ${lc.color}`,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                  <span style={styles.layerBadge(lc.layer)}>{lc.layer}</span>
                  <span style={{ fontSize: '13px', color: COLORS.muted }}>{lc.nameZh}</span>
                </div>
                <div style={{ display: 'flex', gap: '16px' }}>
                  <div>
                    <div style={{ fontSize: '11px', color: COLORS.muted }}>存量</div>
                    <div style={{ fontSize: '24px', fontWeight: 700, color: COLORS.text, fontFamily: "'JetBrains Mono', monospace" }}>
                      {lc.total}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '11px', color: COLORS.muted }}>使用</div>
                    <div style={{ fontSize: '24px', fontWeight: 700, color: COLORS.green, fontFamily: "'JetBrains Mono', monospace" }}>
                      {lc.active}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '11px', color: COLORS.muted }}>新建</div>
                    <div style={{ fontSize: '24px', fontWeight: 700, color: COLORS.primary, fontFamily: "'JetBrains Mono', monospace" }}>
                      {lc.newQ2}
                    </div>
                  </div>
                </div>
                {lc.sizeGB && (
                  <div style={{ fontSize: '12px', color: COLORS.muted, marginTop: '6px', fontFamily: "'JetBrains Mono', monospace" }}>
                    存储: {lc.sizeGB} GB
                  </div>
                )}
                <div style={{ fontSize: '11px', color: COLORS.muted, marginTop: '4px', lineHeight: '1.4' }}>
                  {LAYER_DEFINITIONS[lc.layer]}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Lineage Coverage Card */}
        <div>
          <h3 style={{ fontSize: '16px', fontWeight: 600, color: COLORS.text, marginBottom: '12px' }}>
            血缘覆盖度（按层）
          </h3>
          <div style={{ ...styles.card }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {coverageStats.map(s => (
                <div key={s.layer} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <span style={{ ...styles.layerBadge(s.layer), minWidth: '36px', textAlign: 'center' }}>{s.layer}</span>
                  <div style={{ flex: 1, height: '10px', background: '#F1F3F5', borderRadius: '5px', overflow: 'hidden' }}>
                    <div style={{
                      width: `${s.pct}%`, height: '100%',
                      background: LAYER_COLORS[s.layer],
                      transition: 'width 0.4s',
                    }} />
                  </div>
                  <span style={{ fontSize: '13px', color: COLORS.text, minWidth: '110px', fontFamily: "'JetBrains Mono', monospace" }}>
                    {s.mapped} / {s.total}
                  </span>
                  <span style={{ fontSize: '13px', fontWeight: 600, color: s.pct >= 50 ? COLORS.green : (s.pct >= 20 ? COLORS.gold : COLORS.muted), minWidth: '50px', textAlign: 'right' }}>
                    {s.pct}%
                  </span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: '12px', padding: '8px 12px', background: '#F0F9FF', border: '1px solid #BAE6FD', borderRadius: '6px', fontSize: '12px', color: '#0369A1' }}>
              ℹ️ 血缘数据通过解析 CyberData task.task_content 中的 INSERT/CREATE/FROM/JOIN 语句自动提取。详见 scripts/regenerate_data.py。
            </div>
          </div>
        </div>

        {/* Row 3: ODS Source Database Cards */}
        <div>
          <h3 style={{ fontSize: '16px', fontWeight: 600, color: COLORS.text, marginBottom: '12px' }}>
            ODS库表分布拆解
          </h3>
          <div style={{ overflowX: 'auto', paddingBottom: '8px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, minmax(180px, 1fr))', gap: '12px', minWidth: '950px' }}>
              {ODS_SOURCES.map(src => (
                <div key={src.id} style={{
                  ...styles.card,
                  padding: '14px',
                  borderTop: `3px solid ${LAYER_COLORS.ODS}`,
                }}>
                  <div style={{ ...styles.mono, fontSize: '12px', fontWeight: 500, color: COLORS.text, marginBottom: '4px' }}>
                    {src.name}
                  </div>
                  <div style={{ fontSize: '12px', color: COLORS.muted, marginBottom: '10px' }}>
                    {src.nameZh}
                  </div>
                  <div style={{ display: 'flex', gap: '12px' }}>
                    <div>
                      <div style={{ fontSize: '10px', color: COLORS.muted }}>存量</div>
                      <div style={{ fontSize: '18px', fontWeight: 700, color: COLORS.text, fontFamily: "'JetBrains Mono', monospace" }}>
                        {src.total}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: '10px', color: COLORS.muted }}>使用</div>
                      <div style={{ fontSize: '18px', fontWeight: 700, color: COLORS.green, fontFamily: "'JetBrains Mono', monospace" }}>
                        {src.active}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: '10px', color: COLORS.muted }}>新建</div>
                      <div style={{ fontSize: '18px', fontWeight: 700, color: COLORS.primary, fontFamily: "'JetBrains Mono', monospace" }}>
                        {src.newQ2}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Row 4: CyberData 数据总览 */}
        <div>
          <h3 style={{ fontSize: '16px', fontWeight: 600, color: COLORS.text, marginBottom: '12px' }}>
            数据总览 — 热门表 & 存储/记录排行
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
            {/* Popular Tables */}
            <div style={{ ...styles.card, padding: '0', overflow: 'hidden' }}>
              <div style={{ background: COLORS.navy, color: '#fff', padding: '10px 14px', fontSize: '13px', fontWeight: 600 }}>
                热门表 Top 10
              </div>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>
                  {['#', '表名', '库', '访问'].map(h => (
                    <th key={h} style={{ ...styles.tableHeader, padding: '6px 8px', fontSize: '11px' }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {CYBERDATA_OVERVIEW.popularTables.map((t, i) => (
                    <tr key={i}>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), padding: '4px 8px', fontSize: '11px', textAlign: 'center', cursor: 'default' }}>{i + 1}</td>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, padding: '4px 8px', fontSize: '10px', cursor: 'default' }}>{t.table}</td>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), padding: '4px 8px', fontSize: '10px', color: COLORS.muted, cursor: 'default' }}>{t.db.replace('ods_luckyus_', '').replace('dw_', '')}</td>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, padding: '4px 8px', fontSize: '11px', textAlign: 'right', cursor: 'default' }}>{t.visits}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Records Top by DB */}
            <div style={{ ...styles.card, padding: '0', overflow: 'hidden' }}>
              <div style={{ background: COLORS.navy, color: '#fff', padding: '10px 14px', fontSize: '13px', fontWeight: 600 }}>
                记录数 Top 10
              </div>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>
                  {['#', '数据库', '记录数'].map(h => (
                    <th key={h} style={{ ...styles.tableHeader, padding: '6px 8px', fontSize: '11px' }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {CYBERDATA_OVERVIEW.recordsTopByDb.map((r, i) => (
                    <tr key={i}>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), padding: '4px 8px', fontSize: '11px', textAlign: 'center', cursor: 'default' }}>{i + 1}</td>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, padding: '4px 8px', fontSize: '11px', cursor: 'default' }}>{r.db}</td>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, padding: '4px 8px', fontSize: '11px', textAlign: 'right', cursor: 'default' }}>{r.records}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Storage Top by DB */}
            <div style={{ ...styles.card, padding: '0', overflow: 'hidden' }}>
              <div style={{ background: COLORS.navy, color: '#fff', padding: '10px 14px', fontSize: '13px', fontWeight: 600 }}>
                存储 Top 10
              </div>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>
                  {['#', '数据库', '存储量'].map(h => (
                    <th key={h} style={{ ...styles.tableHeader, padding: '6px 8px', fontSize: '11px' }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {CYBERDATA_OVERVIEW.storageTopByDb.map((s, i) => (
                    <tr key={i}>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), padding: '4px 8px', fontSize: '11px', textAlign: 'center', cursor: 'default' }}>{i + 1}</td>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, padding: '4px 8px', fontSize: '11px', cursor: 'default' }}>{s.db}</td>
                      <td style={{ ...styles.tableCell(i % 2 === 1, false), ...styles.mono, padding: '4px 8px', fontSize: '11px', textAlign: 'right', cursor: 'default' }}>{s.storage}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        </>)}
      </div>
    </div>
  );

  // =========================================================================
  // Screen 2: Lineage
  // =========================================================================
  const renderLineage = () => {
    const lineageData = lineageSelected ? LINEAGE_MAP[lineageSelected] : null;

    // Build 3-column layout: upstream → current → downstream
    const buildLayout = () => {
      if (!lineageData) return null;
      const upstreamNodes = (lineageDirection === 'all' || lineageDirection === 'upstream')
        ? lineageData.upstream : [];
      const downstreamNodes = (lineageDirection === 'all' || lineageDirection === 'downstream')
        ? lineageData.downstream : [];
      return { upstream: upstreamNodes, downstream: downstreamNodes };
    };

    const layout = buildLayout();

    // Group nodes by database for readability
    const groupByDb = (nodes) => {
      const groups = {};
      nodes.forEach(n => {
        if (!groups[n.db]) groups[n.db] = [];
        groups[n.db].push(n);
      });
      return groups;
    };

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {/* Search Bar */}
        <div style={{ ...styles.card, display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
            {/* Text input with suggestions dropdown */}
            <div style={{ flex: 1, position: 'relative' }}>
              <input
                type="text"
                value={lineageSearch}
                onChange={(e) => {
                  const v = e.target.value;
                  setLineageSearch(v);
                  setShowSuggestions(true);
                  if (v && allTableNames.includes(v)) {
                    setLineageSelected(v);
                    setShowSuggestions(false);
                  } else if (v === '') {
                    setLineageSelected(null);
                  }
                }}
                onFocus={() => { if (lineageSearch.length >= 2) setShowSuggestions(true); }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                placeholder="搜索表名..."
                style={{
                  width: '100%', padding: '10px 14px', borderRadius: '8px',
                  border: `1px solid ${COLORS.border}`, fontSize: '14px',
                  fontFamily: "'JetBrains Mono', monospace", outline: 'none',
                }}
              />
              {showSuggestions && lineageSearch.length >= 2 && lineageSuggestions.length === 0 && (
                <div style={{
                  position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 10,
                  background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)', marginTop: '4px',
                  padding: '12px 14px', fontSize: '13px', color: COLORS.muted,
                }}>
                  未找到匹配的表名
                </div>
              )}
              {showSuggestions && lineageSuggestions.length > 0 && (
                <div style={{
                  position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 10,
                  background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)', maxHeight: '200px', overflowY: 'auto',
                  marginTop: '4px',
                }}>
                  {lineageSuggestions.map(key => (
                    <div key={key}
                      onMouseDown={() => { setLineageSearch(key); setLineageSelected(key); setShowSuggestions(false); }}
                      style={{
                        padding: '8px 14px', cursor: 'pointer', fontSize: '13px',
                        fontFamily: "'JetBrains Mono', monospace",
                        borderBottom: `1px solid ${COLORS.rowAlt}`,
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      }}
                      onMouseEnter={(e) => { e.currentTarget.style.background = COLORS.hoverRow; }}
                      onMouseLeave={(e) => { e.currentTarget.style.background = '#fff'; }}
                    >
                      <span>{key}</span>
                      {LINEAGE_MAP[key] ? (
                        <span style={{ fontSize: '10px', color: '#16A34A', background: '#DCFCE7', padding: '1px 6px', borderRadius: '4px' }}>有血缘</span>
                      ) : (
                        <span style={{ fontSize: '10px', color: COLORS.muted, background: '#F3F4F6', padding: '1px 6px', borderRadius: '4px' }}>暂无</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <select
              value={lineageSelected || ''}
              onChange={(e) => handleLineageSearch(e.target.value)}
              style={{
                padding: '10px 14px', borderRadius: '8px',
                border: `1px solid ${COLORS.border}`, fontSize: '13px',
                background: '#fff', cursor: 'pointer', minWidth: '300px', fontFamily: 'inherit',
              }}
            >
              <option value="">快速选择...</option>
              {LINEAGE_QUICK_SELECT.map(qs => (
                <option key={qs.value} value={qs.value}>{qs.label}</option>
              ))}
            </select>
          </div>

          {/* Controls */}
          <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: '4px', background: '#F1F3F5', borderRadius: '8px', padding: '4px' }}>
              {[
                { id: 'all', label: '全链路' },
                { id: 'upstream', label: '只看上游' },
                { id: 'downstream', label: '只看下游' },
              ].map(d => (
                <button
                  key={d.id}
                  onClick={() => setLineageDirection(d.id)}
                  style={{
                    ...styles.tab(lineageDirection === d.id),
                    padding: '6px 14px',
                    fontSize: '13px',
                  }}
                >
                  {d.label}
                </button>
              ))}
            </div>
            <div style={{ display: 'flex', gap: '4px', background: '#F1F3F5', borderRadius: '8px', padding: '4px' }}>
              {[
                { id: 'graph', label: '格式一 图形' },
                { id: 'list', label: '格式二 列表' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setLineageFormat(f.id)}
                  style={{
                    ...styles.tab(lineageFormat === f.id),
                    padding: '6px 14px',
                    fontSize: '13px',
                  }}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Quick-select chip buttons */}
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {LINEAGE_QUICK_SELECT.slice(0, 6).map(qs => (
              <button key={qs.value}
                onClick={() => { setLineageSearch(qs.value); setLineageSelected(qs.value); }}
                style={{
                  padding: '4px 10px', borderRadius: '6px',
                  border: `1px solid ${lineageSelected === qs.value ? COLORS.primary : COLORS.border}`,
                  background: lineageSelected === qs.value ? COLORS.hoverRow : '#fff',
                  cursor: 'pointer', fontSize: '12px',
                  fontFamily: "'JetBrains Mono', monospace",
                  color: lineageSelected === qs.value ? COLORS.primary : COLORS.text,
                }}
              >
                {qs.value}
              </button>
            ))}
          </div>
          <div style={{
            padding: '10px 16px', borderRadius: '8px', marginTop: '8px',
            background: '#F0F9FF', border: '1px solid #BAE6FD',
            fontSize: '12px', color: '#0369A1',
          }}>
            &#8505;&#65039; 血缘数据来源: CyberData 数据开发 SQL 任务定义 · 目前已覆盖 {Object.keys(LINEAGE_MAP).length} 张核心表 · CyberData 血缘图谱功能尚未配置自动采集
          </div>
        </div>

        {/* Content */}
        {!lineageSelected ? (
          // Empty state
          <div style={{ ...styles.card, textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontSize: '48px', marginBottom: '16px', opacity: 0.3 }}>&#128269;</div>
            <div style={{ fontSize: '16px', color: COLORS.muted, marginBottom: '24px' }}>
              请输入或选择一个表名来查看血缘关系
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '40px' }}>
              <div>
                <div style={{ fontSize: '28px', fontWeight: 700, color: COLORS.primary, fontFamily: "'JetBrains Mono', monospace" }}>
                  {LINEAGE_STATS.totalTables}
                </div>
                <div style={{ fontSize: '13px', color: COLORS.muted }}>总表数</div>
              </div>
              <div>
                <div style={{ fontSize: '28px', fontWeight: 700, color: COLORS.teal, fontFamily: "'JetBrains Mono', monospace" }}>
                  {LINEAGE_STATS.totalLinks}
                </div>
                <div style={{ fontSize: '13px', color: COLORS.muted }}>血缘链路</div>
              </div>
              <div>
                <div style={{ fontSize: '28px', fontWeight: 700, color: COLORS.gold, fontFamily: "'JetBrains Mono', monospace" }}>
                  {LINEAGE_STATS.avgDepth}
                </div>
                <div style={{ fontSize: '13px', color: COLORS.muted }}>平均深度</div>
              </div>
              <div>
                <div style={{ fontSize: '28px', fontWeight: 700, color: COLORS.red, fontFamily: "'JetBrains Mono', monospace" }}>
                  {LINEAGE_STATS.maxDepth}
                </div>
                <div style={{ fontSize: '13px', color: COLORS.muted }}>最大深度</div>
              </div>
            </div>
          </div>
        ) : !LINEAGE_MAP[lineageSelected] ? (
          // Table exists in inventory but no lineage data
          <div style={{ ...styles.card, textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontSize: '48px', marginBottom: '16px', opacity: 0.3 }}>&#128466;</div>
            <div style={{ fontSize: '16px', color: COLORS.muted, marginBottom: '8px' }}>
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 600, color: COLORS.text }}>{lineageSelected}</span>
            </div>
            <div style={{ fontSize: '14px', color: COLORS.muted, marginBottom: '24px' }}>
              该表暂无血缘数据 — CyberData 尚未配置该表的 SQL 任务定义或血缘采集
            </div>
            <div style={{
              display: 'inline-block', padding: '10px 20px', borderRadius: '8px',
              background: '#FFF7ED', border: '1px solid #FDBA74', fontSize: '13px', color: '#9A3412',
            }}>
              目前已覆盖 {Object.keys(LINEAGE_MAP).length} 张核心表，可通过快速选择按钮查看已有血缘
            </div>
          </div>
        ) : lineageFormat === 'graph' ? (
          // Graph view — 3-column: upstream → current → downstream
          <div style={{ ...styles.card, overflowX: 'auto' }}>
            {/* Risk warning banners */}
            {lineageData && lineageData.upstream.length + lineageData.downstream.length > 6 && (
              <div style={{
                padding: '10px 16px', borderRadius: '8px', marginBottom: '16px',
                background: '#FFFBEB', border: `1px solid ${COLORS.orange}`,
                fontSize: '13px', color: '#92400E',
              }}>
                &#9888; 该表血缘关系较复杂，共涉及 {lineageData.upstream.length + lineageData.downstream.length + 1} 个节点
              </div>
            )}
            {layout ? (
              <div style={{
                display: 'flex', alignItems: 'flex-start', gap: '24px',
                padding: '24px 0', overflowX: 'auto', minWidth: '800px',
              }}>
                {/* Upstream column */}
                <div style={{
                  display: 'flex', flexDirection: 'column', gap: '8px',
                  minWidth: '280px', maxHeight: '600px', overflowY: 'auto',
                }}>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: COLORS.teal, textAlign: 'center', marginBottom: '8px' }}>
                    上游依赖 ({layout.upstream.length}{layout.upstream.length > 10 ? ' 张表' : ''})
                  </div>
                  {layout.upstream.length > 0 ? (
                    Object.entries(groupByDb(layout.upstream)).map(([db, nodes]) => (
                      <div key={db}>
                        <div style={{ fontSize: '11px', color: COLORS.muted, padding: '4px 0', borderBottom: '1px solid #E5E7EB', marginBottom: '4px' }}>
                          {db} ({nodes.length})
                        </div>
                        {nodes.map((node, i) => (
                          <div key={i} style={{ marginBottom: '6px' }}>
                            <LineageNode table={node.table} layer={node.layer} db={node.db} highlighted={false} refType={node.ref} />
                          </div>
                        ))}
                      </div>
                    ))
                  ) : (
                    <div style={{ color: COLORS.muted, fontSize: '13px', padding: '20px', textAlign: 'center' }}>暂无上游依赖</div>
                  )}
                </div>

                {/* Arrow */}
                <div style={{ display: 'flex', alignItems: 'center', fontSize: '24px', color: COLORS.primary, paddingTop: '40px' }}>&#8594;</div>

                {/* Center: selected table */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', paddingTop: '30px' }}>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: COLORS.primary, marginBottom: '8px' }}>当前表</div>
                  <LineageNode table={lineageSelected} layer={lineageData.layer} db="" highlighted={true} />
                </div>

                {/* Arrow */}
                <div style={{ display: 'flex', alignItems: 'center', fontSize: '24px', color: COLORS.primary, paddingTop: '40px' }}>&#8594;</div>

                {/* Downstream column */}
                <div style={{
                  display: 'flex', flexDirection: 'column', gap: '8px',
                  minWidth: '280px', maxHeight: '600px', overflowY: 'auto',
                }}>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: COLORS.orange, textAlign: 'center', marginBottom: '8px' }}>
                    下游引用 ({layout.downstream.length})
                  </div>
                  {layout.downstream.length > 0 ? (
                    layout.downstream.map((node, i) => (
                      <LineageNode key={i} table={node.table} layer={node.layer} db={node.db} highlighted={false} refType={node.ref} />
                    ))
                  ) : (
                    <div style={{ color: COLORS.muted, fontSize: '13px', padding: '20px', textAlign: 'center' }}>暂无下游引用</div>
                  )}
                </div>
              </div>
            ) : (
              <div style={{ padding: '40px', textAlign: 'center', color: COLORS.muted }}>
                无法加载血缘数据，请重新选择表名
              </div>
            )}
          </div>
        ) : (
          // List view
          <div style={{ ...styles.card, padding: '0', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  {['关系', '层级', '表名', '数据库', '引用方式'].map(h => (
                    <th key={h} style={styles.tableHeader}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {lineageData && (
                  <>
                    <tr>
                      <td style={{ ...styles.tableCell(false, false), fontWeight: 600, color: COLORS.primary }}>当前表</td>
                      <td style={styles.tableCell(false, false)}>
                        <span style={styles.layerBadge(lineageData.layer)}>{lineageData.layer}</span>
                      </td>
                      <td style={{ ...styles.tableCell(false, false), ...styles.mono }}>{lineageSelected}</td>
                      <td style={styles.tableCell(false, false)}>-</td>
                      <td style={styles.tableCell(false, false)}>-</td>
                    </tr>
                    {(lineageDirection === 'all' || lineageDirection === 'upstream') &&
                      lineageData.upstream.map((n, i) => (
                        <tr key={`u-${i}`}>
                          <td style={{ ...styles.tableCell(true, false), color: COLORS.teal }}>上游</td>
                          <td style={styles.tableCell(true, false)}>
                            <span style={styles.layerBadge(n.layer)}>{n.layer}</span>
                          </td>
                          <td style={{ ...styles.tableCell(true, false), ...styles.mono }}>{n.table}</td>
                          <td style={{ ...styles.tableCell(true, false), fontSize: '12px', color: COLORS.muted }}>{n.db}</td>
                          <td style={{ ...styles.tableCell(true, false), ...styles.mono, fontSize: '12px' }}>
                            <span style={{
                              padding: '2px 8px', borderRadius: '4px', fontSize: '11px',
                              background: n.ref === 'JOIN' ? '#DBEAFE' : '#F3E8FF',
                              color: n.ref === 'JOIN' ? '#1D4ED8' : '#7C3AED',
                            }}>{n.ref || 'FROM'}</span>
                          </td>
                        </tr>
                      ))
                    }
                    {(lineageDirection === 'all' || lineageDirection === 'downstream') &&
                      lineageData.downstream.map((n, i) => (
                        <tr key={`d-${i}`}>
                          <td style={{ ...styles.tableCell(false, false), color: COLORS.orange }}>下游</td>
                          <td style={styles.tableCell(false, false)}>
                            <span style={styles.layerBadge(n.layer)}>{n.layer}</span>
                          </td>
                          <td style={{ ...styles.tableCell(false, false), ...styles.mono }}>{n.table}</td>
                          <td style={{ ...styles.tableCell(false, false), fontSize: '12px', color: COLORS.muted }}>{n.db}</td>
                          <td style={{ ...styles.tableCell(false, false), ...styles.mono, fontSize: '12px' }}>
                            <span style={{
                              padding: '2px 8px', borderRadius: '4px', fontSize: '11px',
                              background: n.ref === 'JOIN' ? '#DBEAFE' : '#F3E8FF',
                              color: n.ref === 'JOIN' ? '#1D4ED8' : '#7C3AED',
                            }}>{n.ref || 'FROM'}</span>
                          </td>
                        </tr>
                      ))
                    }
                  </>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Per-table risk warning banners */}
        {lineageData && lineageData.warnings && lineageData.warnings.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {lineageData.warnings.includes('circular_ref') && (
              <div style={{ padding: '12px 16px', borderRadius: '8px', background: '#FEF2F2', border: '1px solid #FECACA', fontSize: '13px', color: '#991B1B' }}>
                &#9888; 该表存在循环引用风险 — 下游表通过其他路径反向引用本表，可能导致调度死锁
              </div>
            )}
            {lineageData.warnings.includes('invalid_ref') && (
              <div style={{ padding: '12px 16px', borderRadius: '8px', background: '#FFFBEB', border: '1px solid #FDE68A', fontSize: '13px', color: '#92400E' }}>
                &#9888; 该表存在无效引用 — 引用的某些上游表已被删除或废弃
              </div>
            )}
            {lineageData.warnings.includes('deep_lineage') && (
              <div style={{ padding: '12px 16px', borderRadius: '8px', background: '#FFFBEB', border: '1px solid #FDE68A', fontSize: '13px', color: '#92400E' }}>
                &#9888; 该表血缘层级超过5层 — 数据穿透率高，查询延迟可能较大，建议优化中间层
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  // =========================================================================
  // Screen 3: Enum Explorer
  // =========================================================================
  const renderEnum = () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {/* Sub-tabs */}
      <div style={{ display: 'flex', gap: '4px', background: '#F1F3F5', borderRadius: '8px', padding: '4px', width: 'fit-content' }}>
        {[
          { id: 'category', label: '字段名归类查看' },
          { id: 'parse', label: '字段名解析查看' },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => { setEnumSubTab(t.id); setEnumPage(1); }}
            style={styles.tab(enumSubTab === t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Search */}
      <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
        <input
          type="text"
          value={enumSearch}
          onChange={(e) => { setEnumSearch(e.target.value); setEnumPage(1); }}
          placeholder="搜索字段名 / 字段描述 / 数据表 / 业务码..."
          style={{
            flex: 1, padding: '10px 14px', borderRadius: '8px',
            border: `1px solid ${COLORS.border}`, fontSize: '14px', outline: 'none',
            fontFamily: 'inherit',
          }}
        />
        {/* Search scope indicators */}
        <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '12px', color: COLORS.muted }}>搜索范围:</span>
          {['数据表', '字段', '业务含义', '业务码'].map(chip => (
            <span key={chip} style={{
              padding: '4px 10px', borderRadius: '12px', fontSize: '11px',
              background: '#F1F3F5', color: COLORS.muted,
              border: `1px solid ${COLORS.border}`,
            }}>
              {chip}
            </span>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', gap: '16px' }}>
        {/* Main Table */}
        <div style={{ flex: 1, ...styles.card, padding: '0', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  {['字段名称', '字段类型', '字段描述', '数据表', '数据库'].map(h => (
                    <th key={h} style={styles.tableHeader}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(enumSubTab === 'parse' ? pagedEnums : filteredGroupedEnums.slice((enumPage - 1) * PAGE_SIZE, enumPage * PAGE_SIZE)).map((field, i) => {
                  const isSelected = selectedField?.id === field.id;
                  return (
                    <tr
                      key={field.id}
                      onClick={() => setSelectedField(isSelected ? null : field)}
                      onMouseEnter={() => setHoveredRow(`enum-${field.id}`)}
                      onMouseLeave={() => setHoveredRow(null)}
                      style={{ cursor: 'pointer' }}
                    >
                      <td style={{
                        ...styles.tableCell(i % 2 === 1, hoveredRow === `enum-${field.id}`),
                        ...styles.mono,
                        fontWeight: 500,
                        color: isSelected ? COLORS.primary : COLORS.text,
                      }}>
                        {field.fieldName}
                        {field.conflict && (
                          <span style={{ color: COLORS.red, marginLeft: '6px', fontSize: '11px' }}>&#9888;</span>
                        )}
                      </td>
                      <td style={{
                        ...styles.tableCell(i % 2 === 1, hoveredRow === `enum-${field.id}`),
                        ...styles.mono,
                        color: COLORS.muted,
                      }}>
                        {field.fieldType}
                      </td>
                      <td style={styles.tableCell(i % 2 === 1, hoveredRow === `enum-${field.id}`)}>
                        {field.description}
                      </td>
                      <td style={{
                        ...styles.tableCell(i % 2 === 1, hoveredRow === `enum-${field.id}`),
                        ...styles.mono,
                        fontSize: '12px',
                        maxWidth: '200px',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}>
                        {(field.allTables || field.tables).join(', ')}
                      </td>
                      <td style={{
                        ...styles.tableCell(i % 2 === 1, hoveredRow === `enum-${field.id}`),
                        fontSize: '12px',
                        color: COLORS.muted,
                      }}>
                        {field.db}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination
            total={enumSubTab === 'parse' ? filteredEnums.length : filteredGroupedEnums.length}
            page={enumPage}
            pageSize={PAGE_SIZE}
            onChange={setEnumPage}
          />
        </div>

        {/* Right Detail Panel */}
        {selectedField && (
          <div style={{
            width: '380px',
            flexShrink: 0,
            ...styles.card,
            position: 'relative',
            alignSelf: 'flex-start',
            maxHeight: 'calc(100vh - 200px)',
            overflowY: 'auto',
          }}>
            <button
              onClick={() => setSelectedField(null)}
              style={{
                position: 'absolute', top: '12px', right: '12px',
                background: 'none', border: 'none', cursor: 'pointer',
                fontSize: '18px', color: COLORS.muted, fontFamily: 'inherit',
              }}
            >
              &#10005;
            </button>
            <div style={{ marginBottom: '16px' }}>
              <div style={{ ...styles.mono, fontSize: '18px', fontWeight: 600, color: COLORS.text }}>
                {selectedField.fieldName}
              </div>
              <div style={{ fontSize: '14px', color: COLORS.muted, marginTop: '4px' }}>
                {selectedField.description}
              </div>
            </div>

            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '16px' }}>
              <span style={styles.badge(COLORS.primary)}>{selectedField.fieldType}</span>
              <span style={styles.badge(COLORS.teal)}>{selectedField.domain}</span>
              {selectedField.conflict && <span style={styles.badge(COLORS.red)}>存在冲突</span>}
            </div>

            {/* Tables using this field */}
            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontSize: '13px', fontWeight: 600, color: COLORS.text, marginBottom: '8px' }}>使用此字段的表:</div>
              {(selectedField.allTables || selectedField.tables).map((t, i) => (
                <div key={i} style={{
                  ...styles.mono, fontSize: '12px', padding: '4px 0',
                  color: COLORS.text, borderBottom: `1px solid ${COLORS.border}`,
                }}>
                  {t}
                </div>
              ))}
            </div>

            {/* Business code box */}
            <div style={{
              background: COLORS.yellowBg,
              border: `1px solid ${COLORS.yellowBorder}`,
              borderRadius: '8px',
              padding: '16px',
            }}>
              <div style={{ fontSize: '13px', fontWeight: 600, color: '#92400E', marginBottom: '8px' }}>
                业务码定义
              </div>
              <div style={{
                ...styles.mono,
                fontSize: '12px',
                color: '#78350F',
                lineHeight: '1.8',
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-all',
              }}>
                {selectedField.values.split('; ').join('\n')}
              </div>
            </div>

            {/* Conflict note */}
            {selectedField.conflict && selectedField.conflictNote && (
              <div style={{
                marginTop: '12px', padding: '12px', borderRadius: '8px',
                background: '#FEF2F2', border: '1px solid #FECACA',
              }}>
                <div style={{ fontSize: '12px', fontWeight: 600, color: COLORS.red, marginBottom: '4px' }}>
                  &#9888; 冲突说明
                </div>
                <div style={{ fontSize: '12px', color: '#991B1B', lineHeight: '1.6' }}>
                  {selectedField.conflictNote}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );

  // =========================================================================
  // Screen 4: Risk Analysis
  // =========================================================================
  const renderRisk = () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {RISK_SECTIONS.map(section => (
        <div key={section.id}>
          <div style={{
            background: COLORS.navy, color: '#fff', padding: '12px 20px',
            borderRadius: '8px', marginBottom: '16px',
            fontSize: '16px', fontWeight: 600,
          }}>
            {section.title}
          </div>
          {section.risks.map(risk => (
            <RiskCard
              key={risk.id}
              risk={risk}
              expanded={!!expandedRisks[risk.id]}
              onToggle={toggleRisk}
            />
          ))}
        </div>
      ))}
    </div>
  );

  // =========================================================================
  // Main Render
  // =========================================================================
  return (
    <div style={{ minHeight: '100vh', background: COLORS.pageBg }}>
      {/* Header */}
      <div style={styles.header}>
        <div style={{ maxWidth: '1600px', margin: '0 auto' }}>
          <h1 style={{ fontSize: '22px', fontWeight: 700, marginBottom: '4px' }}>
            国际化数仓运维看板
          </h1>
          <div style={{ display: 'flex', gap: '16px', fontSize: '13px', opacity: 0.8, flexWrap: 'wrap' }}>
            <span>瑞幸咖啡北美 · 大数据团队</span>
            <span>|</span>
            <span>Q2 2026 · 53库 · {LINEAGE_STATS.totalTables.toLocaleString()}表 · 121.45 GB</span>
            <span>|</span>
            <span>血缘覆盖: {Object.keys(LINEAGE_MAP).length} / {LINEAGE_STATS.totalTables}</span>
            <span>|</span>
            <span>快照: 2026-04-28</span>
          </div>
        </div>
      </div>

      {/* Verify-table search bar (云飞 acceptance test) */}
      <div style={{ maxWidth: '1600px', margin: '12px auto 0', padding: '0 32px' }}>
        <div style={{
          background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: '10px',
          padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: '10px',
        }}>
          <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
            <span style={{ fontSize: '13px', fontWeight: 600, color: COLORS.text, whiteSpace: 'nowrap' }}>
              库表验证 (Verify Table):
            </span>
            <input
              type="text"
              value={verifyQuery}
              onChange={(e) => setVerifyQuery(e.target.value)}
              placeholder="输入表名验证（例：dwd_mg_order_first_detail_d_his）— 测试本看板是否覆盖完整"
              style={{
                flex: 1, padding: '8px 12px', borderRadius: '6px',
                border: `1px solid ${COLORS.border}`, fontSize: '13px',
                fontFamily: "'JetBrains Mono', monospace", outline: 'none',
              }}
            />
            <span style={{ fontSize: '12px', color: COLORS.muted, whiteSpace: 'nowrap' }}>
              共 {DIM_TABLES.length + DWD_TABLES.length + DWS_TABLES.length + ADS_TABLES.length + ODS_TABLES.length} 张本看板已收录
            </span>
          </div>
          {verifyResult && verifyResult.mode === 'exact' && (
            <div style={{ padding: '10px 14px', borderRadius: '6px', background: '#F0FDF4', border: `1px solid ${COLORS.green}`, fontSize: '13px' }}>
              <span style={{ color: COLORS.green, fontWeight: 600 }}>✅ 已收录</span>
              <span style={{ marginLeft: '12px', fontFamily: "'JetBrains Mono', monospace" }}>{verifyResult.match.name}</span>
              <span style={{ marginLeft: '12px', ...styles.layerBadge(verifyResult.match.layer) }}>{verifyResult.match.layer}</span>
              <span style={{ marginLeft: '12px', color: COLORS.muted }}>{verifyResult.match.db}</span>
              {verifyResult.match.nameZh && <span style={{ marginLeft: '12px', color: COLORS.text }}>· {verifyResult.match.nameZh}</span>}
              <span style={{ marginLeft: '12px', color: verifyResult.match.hasLineage ? COLORS.primary : COLORS.muted, fontSize: '12px' }}>
                {verifyResult.match.hasLineage ? '· 血缘已配置 ✓' : '· 血缘未配置'}
              </span>
            </div>
          )}
          {verifyResult && verifyResult.mode === 'partial' && (
            <div style={{ padding: '10px 14px', borderRadius: '6px', background: '#FEFCE8', border: `1px solid ${COLORS.gold}`, fontSize: '13px' }}>
              <div style={{ marginBottom: '6px' }}>
                <span style={{ color: COLORS.gold, fontWeight: 600 }}>🔍 找到 {verifyResult.matches.length} 个相关表（精确名未匹配，但发现部分匹配）：</span>
              </div>
              {verifyResult.matches.map((m, i) => (
                <div key={i} style={{ padding: '4px 0', fontSize: '12px' }}>
                  <span style={{ ...styles.layerBadge(m.layer), marginRight: '8px' }}>{m.layer}</span>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>{m.name}</span>
                  <span style={{ marginLeft: '8px', color: COLORS.muted }}>{m.db}</span>
                </div>
              ))}
            </div>
          )}
          {verifyResult && verifyResult.mode === 'none' && (
            <div style={{ padding: '10px 14px', borderRadius: '6px', background: '#FEF2F2', border: `1px solid ${COLORS.red}`, fontSize: '13px' }}>
              <span style={{ color: COLORS.red, fontWeight: 600 }}>❌ 未在本看板收录</span>
              <span style={{ marginLeft: '12px', color: COLORS.muted }}>
                查询 "{verifyQuery}" 未匹配任何已收录的表。请确认表名拼写或联系平台组确认是否已注册到 CyberData。
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Tab Bar */}
      <div style={{ maxWidth: '1600px', margin: '0 auto' }}>
        <div style={styles.tabBar}>
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              style={styles.tab(activeTab === tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: '1600px', margin: '0 auto', padding: '0 32px 32px' }}>
        {activeTab === 'overview' && renderOverview()}
        {activeTab === 'lineage' && renderLineage()}
        {activeTab === 'enum' && renderEnum()}
        {activeTab === 'risk' && renderRisk()}
      </div>

      {/* Footer */}
      <div style={{
        borderTop: `1px solid ${COLORS.border}`, marginTop: '20px',
      }}>
        <div style={{
          display: 'flex', justifyContent: 'space-between', padding: '16px 32px',
          fontSize: '12px', color: COLORS.muted,
          maxWidth: '1600px', margin: '0 auto',
        }}>
          <span>国际化数仓运维看板 v2.0 · Luckin Coffee North America · DBA Team</span>
          <span>数据源: CyberData (luckyus_icyberdata) · {LINEAGE_STATS.totalTables.toLocaleString()}表 · 血缘 {Object.keys(LINEAGE_MAP).length} 项 · 快照: 2026-04-28 · 联系人: 田洪彬 / 云飞</span>
        </div>
      </div>
    </div>
  );
}
