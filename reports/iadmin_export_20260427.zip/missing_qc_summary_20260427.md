# Missing QC Attachments — Summary (2026-04-27)

**Source**: `aws-luckyus-scmsrm-rw` / `luckyus_scm_srm`

**Tenant**: `LKUS`  ·  **Scope**: 大类 ∈ {原料, 轻食, 包装类}, spec.status=1

**Slot mapping**:
- 产品标签附件 = `t_mdm_goods_spec_attachment.type=1`
- 外/中/内包装照片 = `t_mdm_goods_spec_images.unit_type=1/2/3` (procurement / distribution / warehouse-stock unit)
- 产品规格书附件 = `t_mdm_goods_spec_attachment.type=2`
- 其他附件 = `t_mdm_goods_spec_attachment.type IN (3,4,5,6,7)`

## Coverage by 大类

| 大类 | In-scope specs | Specs missing ≥1 slot | Coverage gap |
|---|---:|---:|---:|
| 原料 | 105 | 95 | 90.5% |
| 包装类 | 42 | 28 | 66.7% |
| 轻食 | 12 | 7 | 58.3% |
| **Total** | **159** | **130** | **81.8%** |

## 大类 × Slot matrix (count of specs missing each slot)

| 大类 | 产品标签附件 | 外包装照片 | 中包装照片 | 内包装照片 | 产品规格书附件 | 其他附件 |
|---|---:|---:|---:|---:|---:|---:|
| 原料 | 48 | 0 | 0 | 0 | 46 | 93 |
| 包装类 | 28 | 0 | 0 | 0 | 28 | 28 |
| 轻食 | 6 | 0 | 0 | 0 | 5 | 6 |

## Distribution of `total_missing_count`

| Slots missing | # specs |
|---:|---:|
| 1 | 51 |
| 3 | 79 |

## Notable findings

- **79 specs have ZERO file attachments** (no label, no spec doc, no other) — these specs all show `total_missing_count = 3`.
- All 159 in-scope specs have packaging photos at every unit_type level (1/2/3) — the file-attachment slots are where the gap is.
- Worst category by gap rate: **原料** (95 of 105 = 90% with at least one missing slot).
- 包装类 has a uniform pattern: every one of the 28 affected specs is missing all three file slots — suggests a category-wide gap.
