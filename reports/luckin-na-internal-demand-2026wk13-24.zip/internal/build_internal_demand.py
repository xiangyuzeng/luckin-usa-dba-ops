#!/usr/bin/env python3
"""
build_internal_demand.py
========================
Luckin Coffee NA — internal demand-curve extraction for trading-hours analysis.

This script does NOT touch the database. All numbers originate from live read-only
SELECTs against the production salesorder/opshop MySQL (via mcp-db-gateway), whose
JSON outputs were persisted verbatim into ./raw/ :

  raw/q1_hour_dow_channel.json  per-store [local_dow, local_hour, channel_bucket, orders, revenue]
  raw/q2_daily_edges.json       per-store [local_date, first_pay_utc, last_pay_utc, orders, revenue]
  raw/store_master.json         t_shop_info (active US stores; store_id = dept_id = t_order.shop_id)
  raw/posted_hours.json         t_shop_opening_time modal open/close per store
  raw/control_totals.json       independent per-store COUNT/SUM used to verify Q1 losslessness

Window: 12 complete weeks ending Sun 2026-06-21 -> local dates 2026-03-30 .. 2026-06-21.
The whole window sits inside US EDT (DST began 2026-03-08), so UTC->America/New_York is a
uniform -4h; Q1 local hour/dow were computed in SQL via (pay_time - INTERVAL 4 HOUR) and Q2
edge instants are converted per-instant with zoneinfo (fully DST-correct, general).

MySQL DAYOFWEEK: 1=Sun, 2=Mon, ... 7=Sat.
Channel buckets: 1,2,3 kept as ch1/ch2/ch3; everything else -> 'other' (codes not decoded:
no channel dictionary table located). 'all' = sum over channels.
"""
from __future__ import annotations
import json, csv, os, math, datetime as dt
from collections import defaultdict
from zoneinfo import ZoneInfo

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, "raw")
OUT = BASE
ANALYSIS_WEEKS = 12
WINDOW_START = dt.date(2026, 3, 30)
WINDOW_END   = dt.date(2026, 6, 21)   # inclusive last local date
RAMP_CUTOFF  = dt.date(2026, 4, 26)   # opened after this => <8 weeks before window end
UTC = ZoneInfo("UTC")

DOW_NAME = {1:"Sunday",2:"Monday",3:"Tuesday",4:"Wednesday",5:"Thursday",6:"Friday",7:"Saturday"}
WEEKEND_DOW = {1, 7}   # Sun, Sat
def day_type(dow): return "weekend" if dow in WEEKEND_DOW else "weekday"
def ch_label(c): return {0:"other",1:"ch1",2:"ch2",3:"ch3"}.get(int(c), f"ch{c}")

log_lines = []
def log(msg):
    log_lines.append(msg)
    print(msg)

# ---------------------------------------------------------------- load
def load(name):
    with open(os.path.join(RAW, name)) as f:
        return json.load(f)

q1 = {r["shop_id"]: json.loads(r["j"]) for r in load("q1_hour_dow_channel.json")["rows"]}
q2 = {r["shop_id"]: json.loads(r["j"]) for r in load("q2_daily_edges.json")["rows"]}
master = {r["store_id"]: r for r in load("store_master.json")}
control = {r["store_id"]: r for r in load("control_totals.json")}

posted_rows = load("posted_hours.json")
posted = {}   # store_id -> {open, close, days, alts}
for r in posted_rows:
    sid = r["store_id"]
    if r.get("is_business") != 1:
        continue
    cur = posted.get(sid)
    if cur is None or r["days"] > cur["days"]:
        if cur is not None:
            cur.setdefault("alts", [])
        posted[sid] = {"open": r["open"], "close": r["close"], "days": r["days"], "alts": []}
for r in posted_rows:
    sid = r["store_id"]
    if r.get("is_business") == 1 and sid in posted:
        if (r["open"], r["close"]) != (posted[sid]["open"], posted[sid]["close"]):
            posted[sid]["alts"].append(f'{r["open"]}-{r["close"]}({r["days"]}d)')

STORES = sorted(master.keys(), key=lambda s: (-control[s]["orders"]))

log("="*78)
log("SCHEMA RESOLUTION REPORT")
log("="*78)
log("Engine: mysql (read replica path = mcp-db-gateway; env DB_ENGINE unset -> used the")
log("        project's documented live read-only gateway, NOT direct env-var driver).")
log("ORDERS table : luckyus_sales_order.t_order  (~1.01M rows)")
log("  ts col     : pay_time (datetime, UTC)  [paid/settled time preferred over create_time]")
log("  store col  : shop_id  (== t_shop_info.dept_id == join key 'store_id')")
log("  amount col : pay_money (decimal, actual paid)")
log("  channel col: channel (smallint; numeric codes, dictionary NOT located -> kept as codes)")
log("  status col : status; successful/paid filter = status IN (20,90) AND pay_time NOT NULL")
log("               (90=completed dominant 375k/12wk; 20=paid-in-flight; 0/10=unpaid/new)")
log("STORES table : luckyus_opshop.t_shop_info ; id/dept_id, shop_name, address,")
log("               location_latitude/longitude, time_zone(IANA), set_up_time(open), status")
log("POSTED hours : luckyus_opshop.t_shop_opening_time (dept_id+date; opening_start/end HH:mm)")
log("LABOR (Q4)   : luckyus_opempefficiency.t_attendance_shift EXISTS (32,301 rows) but carries")
log("               no wage/cost data -> labor cost-per-hour SKIPPED (no fabrication).")
log(f"Scope        : {len(STORES)} active US stores (America/New_York; test/internal excluded)")
log(f"Window       : {WINDOW_START}..{WINDOW_END} local ({ANALYSIS_WEEKS} complete weeks; all EDT/UTC-4)")
log("")

# ---------------------------------------------------------------- helpers
def pct(sorted_vals, p):
    if not sorted_vals: return None
    if len(sorted_vals) == 1: return float(sorted_vals[0])
    k = (len(sorted_vals)-1) * (p/100.0)
    lo, hi = math.floor(k), math.ceil(k)
    if lo == hi: return float(sorted_vals[int(k)])
    return sorted_vals[lo]*(hi-k) + sorted_vals[hi]*(k-lo)

def minutes_to_hhmm(m):
    if m is None: return ""
    m = int(round(m)); return f"{(m//60)%24:02d}:{m%60:02d}"

# ---------------------------------------------------------------- per-store compute
demand_dow_rows = []      # store_id, dow, hour_local, channel, orders, revenue, avg_ticket
demand_dtype_rows = []    # store_id, day_type, hour_local, channel, orders, revenue
edges_rows = []           # store_id, date_local, first_order_local, last_order_local, orders, revenue
edge_summary_rows = []
master_rows = []
rec_inputs = {}

verify_ok = True
for sid in STORES:
    m = master[sid]; tz = ZoneInfo(m["tz"]); ctl = control[sid]
    ph = posted.get(sid, {"open":"unknown","close":"unknown","days":0,"alts":[]})

    # ---- Q1: (dow, hour, channel) -> aggregates
    # hour_dow_ch[dow][hour][chlabel] = [orders, revenue]
    hd_all_hour = defaultdict(lambda: [0,0.0])         # local hour -> [orders,rev] (all dow, all ch)
    hd_dow_hour_ch = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda:[0,0.0])))
    dtype_hour_ch  = defaultdict(lambda: defaultdict(lambda:[0,0.0]))
    chan_tot = defaultdict(int)
    tot_orders = 0; tot_rev = 0.0
    for dow, h, ch, o, r in q1[sid]:
        cl = ch_label(ch)
        hd_dow_hour_ch[dow][h][cl][0]+=o; hd_dow_hour_ch[dow][h][cl][1]+=r
        dt_ = day_type(dow)
        dtype_hour_ch[(dt_,h)][cl][0]+=o; dtype_hour_ch[(dt_,h)][cl][1]+=r
        hd_all_hour[h][0]+=o; hd_all_hour[h][1]+=r
        chan_tot[cl]+=o
        tot_orders+=o; tot_rev+=r

    # verify against control totals (losslessness)
    if tot_orders != ctl["orders"] or abs(tot_rev - ctl["revenue"]) > 1.0:
        verify_ok = False
        log(f"  !! VERIFY MISMATCH store {sid}: Q1 sum orders={tot_orders} rev={tot_rev:.2f} "
            f"vs control orders={ctl['orders']} rev={ctl['revenue']}")

    # emit demand_by_hour_dow (per-channel + 'all')
    for dow in sorted(hd_dow_hour_ch):
        for h in sorted(hd_dow_hour_ch[dow]):
            all_o = sum(v[0] for v in hd_dow_hour_ch[dow][h].values())
            all_r = sum(v[1] for v in hd_dow_hour_ch[dow][h].values())
            demand_dow_rows.append([sid, DOW_NAME[dow], h, "all", all_o, round(all_r,2),
                                    round(all_r/all_o,4) if all_o else 0])
            for cl,(o,r) in sorted(hd_dow_hour_ch[dow][h].items()):
                demand_dow_rows.append([sid, DOW_NAME[dow], h, cl, o, round(r,2),
                                        round(r/o,4) if o else 0])
    # emit demand_by_hour_daytype (per-channel + 'all')
    for (dt_,h) in sorted(dtype_hour_ch):
        all_o = sum(v[0] for v in dtype_hour_ch[(dt_,h)].values())
        all_r = sum(v[1] for v in dtype_hour_ch[(dt_,h)].values())
        demand_dtype_rows.append([sid, dt_, h, "all", all_o, round(all_r,2)])
        for cl,(o,r) in sorted(dtype_hour_ch[(dt_,h)].items()):
            demand_dtype_rows.append([sid, dt_, h, cl, o, round(r,2)])

    # ---- Q2: daily edges -> first/last local, percentiles, day_type day counts
    first_min=[]; last_min=[]
    wd_days=0; we_days=0
    for d_str, ft, lt, o, r in q2[sid]:
        f_utc = dt.datetime.fromisoformat(ft).replace(tzinfo=UTC)
        l_utc = dt.datetime.fromisoformat(lt).replace(tzinfo=UTC)
        f_loc = f_utc.astimezone(tz); l_loc = l_utc.astimezone(tz)
        fm = f_loc.hour*60+f_loc.minute+f_loc.second/60.0
        lm = l_loc.hour*60+l_loc.minute+l_loc.second/60.0
        first_min.append(fm); last_min.append(lm)
        edges_rows.append([sid, d_str, f_loc.strftime("%H:%M:%S"), l_loc.strftime("%H:%M:%S"), o, round(r,2)])
        # day_type by local date weekday: python weekday() Mon=0..Sun=6
        wd = dt.date.fromisoformat(d_str).weekday()
        if wd >= 5: we_days += 1
        else: wd_days += 1
    first_min.sort(); last_min.sort()
    f_p50, f_p90 = pct(first_min,50), pct(first_min,90)
    l_p50, l_p90 = pct(last_min,50), pct(last_min,90)

    # ---- pressure & leakage from local-hour totals
    open_h = int(ph["open"][:2]) if ph["open"]!="unknown" else None
    close_h = int(ph["close"][:2]) if ph["close"]!="unknown" else None
    hour_orders = {h: hd_all_hour[h][0] for h in hd_all_hour}
    midday_ref = (hour_orders.get(12,0)+hour_orders.get(13,0)+hour_orders.get(14,0))/3.0
    def safe_ratio(n): return round(n/midday_ref,3) if midday_ref>0 else None
    opening_pressure = safe_ratio(hour_orders.get(open_h,0)) if open_h is not None else None
    closing_pressure = safe_ratio(hour_orders.get(close_h-1,0)) if close_h is not None else None
    pct_before = round(100*sum(o for h,o in hour_orders.items() if open_h is not None and h<open_h)/tot_orders,2) if tot_orders else 0
    pct_after  = round(100*sum(o for h,o in hour_orders.items() if close_h is not None and h>=close_h)/tot_orders,2) if tot_orders else 0

    # ---- confidence
    open_date = dt.date.fromisoformat(m["open_date"]) if m.get("open_date") else None
    weeks = ctl["active_weeks"]; adays = ctl["active_days"]
    avg_daily = tot_orders/adays if adays else 0
    flags=[]
    if open_date and open_date > RAMP_CUTOFF: flags.append("ramp_up(<8wk)")
    if weeks < 8: flags.append(f"weeks={weeks}")
    if avg_daily < 100: flags.append(f"low_vol({avg_daily:.0f}/day)")
    if open_date and open_date > RAMP_CUTOFF or weeks < 8 or avg_daily < 100:
        confidence = "low"
    elif weeks < ANALYSIS_WEEKS:
        confidence = "medium"
    else:
        confidence = "high"

    # ---- master row
    master_rows.append([sid, m["shop_no"], m["name"], m["address"], m["lat"], m["lng"], m["tz"],
                        m["open_date"], m["status"], ph["open"], ph["close"], ph["days"],
                        ";".join(ph["alts"]) if ph["alts"] else ""])

    # ---- recommendation_inputs bundle
    def hourly_list(which):
        days = we_days if which=="weekend" else wd_days
        out=[]
        for h in range(0,24):
            o = sum(dtype_hour_ch[(which,h)][cl][0] for cl in dtype_hour_ch.get((which,h),{})) \
                if (which,h) in dtype_hour_ch else 0
            r = sum(dtype_hour_ch[(which,h)][cl][1] for cl in dtype_hour_ch.get((which,h),{})) \
                if (which,h) in dtype_hour_ch else 0.0
            if o:
                out.append({"hour":h,"orders":o,"avg_per_day":round(o/days,2) if days else None,
                            "revenue":round(r,2)})
        return out
    chan_mix = {cl: round(chan_tot[cl]/tot_orders,4) for cl in sorted(chan_tot)} if tot_orders else {}
    rec_inputs[str(sid)] = {
        "store_id": sid, "name": m["name"], "address": m["address"],
        "lat": m["lat"], "lng": m["lng"], "tz": m["tz"],
        "current_hours": {"open": ph["open"], "close": ph["close"],
                          "posted_days": ph["days"], "alt_schedules": ph["alts"]},
        "weeks_covered": weeks, "active_days": adays, "total_orders": tot_orders,
        "total_revenue": round(tot_rev,2), "avg_orders_per_day": round(avg_daily,1),
        "weekday_hourly": hourly_list("weekday"),
        "weekend_hourly": hourly_list("weekend"),
        "first_order_local": {"p50": minutes_to_hhmm(f_p50), "p90": minutes_to_hhmm(f_p90)},
        "last_order_local":  {"p50": minutes_to_hhmm(l_p50), "p90": minutes_to_hhmm(l_p90)},
        "opening_pressure": opening_pressure, "closing_pressure": closing_pressure,
        "pct_orders_before_open": pct_before, "pct_orders_after_close": pct_after,
        "channel_mix": chan_mix, "confidence": confidence, "flags": flags,
    }

    edge_summary_rows.append([sid, m["name"], minutes_to_hhmm(f_p50), minutes_to_hhmm(f_p90),
                              minutes_to_hhmm(l_p50), minutes_to_hhmm(l_p90),
                              opening_pressure, closing_pressure, pct_before, pct_after,
                              weeks, confidence])

    # ---- per-store checkpoint
    with open(os.path.join(RAW, f"{sid}.json"), "w") as f:
        json.dump({"store_id":sid,"name":m["name"],"window":[str(WINDOW_START),str(WINDOW_END)],
                   "totals":{"orders":tot_orders,"revenue":round(tot_rev,2),
                             "weeks":weeks,"active_days":adays},
                   "posted_hours":ph,
                   "hour_dow_channel":q1[sid],
                   "rec_inputs":rec_inputs[str(sid)]}, f, indent=1)

log(f"Integrity check (Q1 vs control totals): {'PASS - lossless' if verify_ok else 'FAIL - see mismatches'}")
log(f"Rows: demand_by_hour_dow={len(demand_dow_rows)} demand_by_hour_daytype={len(demand_dtype_rows)} "
    f"store_daily_edges={len(edges_rows)}")
log("TZ: all stores America/New_York (from t_shop_info.time_zone); no lat/lng tz-derivation needed.")
log("Channel codes left numeric (no dictionary table). Per-hour channel split retained.")

# ---------------------------------------------------------------- write CSVs
def write_csv(name, header, rows):
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)

write_csv("demand_by_hour_dow.csv",
          ["store_id","dow","hour_local","channel","orders","revenue","avg_ticket"], demand_dow_rows)
write_csv("demand_by_hour_daytype.csv",
          ["store_id","day_type","hour_local","channel","orders","revenue"], demand_dtype_rows)
write_csv("store_daily_edges.csv",
          ["store_id","date_local","first_order_local","last_order_local","orders","revenue"], edges_rows)
write_csv("edge_summary.csv",
          ["store_id","store_name","first_order_p50","first_order_p90","last_order_p50",
           "last_order_p90","opening_pressure","closing_pressure","pct_before_open",
           "pct_after_close","weeks_covered","confidence"], edge_summary_rows)
write_csv("store_master.csv",
          ["store_id","shop_no","name","address","lat","lng","tz","open_date","status",
           "current_open","current_close","posted_days","posted_alt_schedules"], master_rows)

with open(os.path.join(OUT, "recommendation_inputs.json"), "w") as f:
    json.dump(rec_inputs, f, indent=1)

# ---------------------------------------------------------------- xlsx
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
    NAVY = PatternFill("solid", fgColor="1F4E79")
    WHITEB = Font(color="FFFFFF", bold=True)
    THIN = Border(*[Side(style="thin", color="D0D0D0")]*4)
    def style_header(ws, ncol):
        for c in range(1, ncol+1):
            cell = ws.cell(row=1, column=c); cell.fill=NAVY; cell.font=WHITEB
            cell.alignment=Alignment(horizontal="center")
    def autoborder(ws, nrow, ncol):
        for rr in range(1,nrow+1):
            for cc in range(1,ncol+1):
                ws.cell(row=rr,column=cc).border=THIN
    wb = Workbook(); ws = wb.active; ws.title="Summary"
    sh = ["store_id","name","current_open","current_close","weekday_peak_hour","weekend_peak_hour",
          "first_order_p50","last_order_p50","opening_pressure","closing_pressure",
          "early_pct(before_open)","late_pct(after_close)","weeks","confidence"]
    ws.append(sh)
    for sid in STORES:
        ri = rec_inputs[str(sid)]
        wd = max(ri["weekday_hourly"], key=lambda x:x["orders"], default={"hour":None})["hour"]
        we = max(ri["weekend_hourly"], key=lambda x:x["orders"], default={"hour":None})["hour"]
        ws.append([sid, ri["name"], ri["current_hours"]["open"], ri["current_hours"]["close"],
                   wd, we, ri["first_order_local"]["p50"], ri["last_order_local"]["p50"],
                   ri["opening_pressure"], ri["closing_pressure"],
                   ri["pct_orders_before_open"], ri["pct_orders_after_close"],
                   ri["weeks_covered"], ri["confidence"]])
    style_header(ws, len(sh)); autoborder(ws, len(STORES)+1, len(sh))
    for col,wdt in zip("ABCDEFGHIJKLMN",[9,20,12,12,16,16,14,13,16,16,20,20,7,11]):
        ws.column_dimensions[col].width=wdt
    # per-store hour x day_type sheet
    for sid in STORES:
        ri = rec_inputs[str(sid)]
        wsx = wb.create_sheet(title=str(sid)[:31])
        wsx.append(["hour_local","weekday_orders","weekday_avg/day","weekend_orders","weekend_avg/day"])
        wdm = {x["hour"]:x for x in ri["weekday_hourly"]}
        wem = {x["hour"]:x for x in ri["weekend_hourly"]}
        hrs = sorted(set(wdm)|set(wem))
        for h in hrs:
            a=wdm.get(h); b=wem.get(h)
            wsx.append([h, a["orders"] if a else 0, a["avg_per_day"] if a else 0,
                        b["orders"] if b else 0, b["avg_per_day"] if b else 0])
        style_header(wsx,5); autoborder(wsx,len(hrs)+1,5)
        for col,wdt in zip("ABCDE",[11,15,16,15,16]): wsx.column_dimensions[col].width=wdt
    wb.save(os.path.join(OUT,"summary.xlsx"))
    log("summary.xlsx written (Summary + per-store sheets, navy header #1F4E79).")
except Exception as e:
    log(f"xlsx generation FAILED: {e}")

# ---------------------------------------------------------------- run.log + console table
with open(os.path.join(OUT,"run.log"),"w") as f:
    f.write("\n".join(log_lines)+"\n")

print("\n" + "="*132)
print("PER-STORE SUMMARY  (window 2026-03-30..2026-06-21, 12 wk; times local America/New_York)")
print("="*132)
hdr = f'{"store_id":>8} {"name":<18} {"hours":<11} {"1st_p50":>7} {"last_p50":>8} {"open_pr":>7} {"close_pr":>8} {"early%":>6} {"late%":>6} {"wks":>3} {"conf":<7}'
print(hdr); print("-"*132)
for sid in STORES:
    ri=rec_inputs[str(sid)]
    print(f'{sid:>8} {ri["name"][:18]:<18} '
          f'{ri["current_hours"]["open"]+"-"+ri["current_hours"]["close"]:<11} '
          f'{ri["first_order_local"]["p50"]:>7} {ri["last_order_local"]["p50"]:>8} '
          f'{str(ri["opening_pressure"]):>7} {str(ri["closing_pressure"]):>8} '
          f'{ri["pct_orders_before_open"]:>6} {ri["pct_orders_after_close"]:>6} '
          f'{ri["weeks_covered"]:>3} {ri["confidence"]:<7}')
print("="*132)
