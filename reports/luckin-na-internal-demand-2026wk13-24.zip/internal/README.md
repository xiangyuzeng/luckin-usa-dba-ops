# Internal demand-curve extraction (trading-hours analysis)

Per-store actual hourly demand + edge-of-window behavior for the 18 active Luckin NA
stores, built **only from live read-only SELECTs** against production
`luckyus_sales_order.t_order` + `luckyus_opshop` (via mcp-db-gateway). Window: 12
complete weeks **2026-03-30 .. 2026-06-21** (local America/New_York; entirely EDT).

## Join key
`store_id` = `t_order.shop_id` = `t_shop_info.dept_id`. Merge these outputs with the
Google-Maps competitor-hours output on `store_id` (use `store_master.csv` address/lat/lng
to align the Maps input, which keys on address).

## Files
| File | Contents |
|------|----------|
| `demand_by_hour_dow.csv` | store × weekday-name × local hour × channel (+`all`): orders, revenue, avg_ticket |
| `demand_by_hour_daytype.csv` | store × weekday/weekend × local hour × channel (+`all`) |
| `store_daily_edges.csv` | per store-day: first/last order local time, orders, revenue |
| `edge_summary.csv` | per store: first/last p50&p90, opening/closing pressure, leakage %, weeks, confidence |
| `store_master.csv` | id/name/address/lat/lng/tz/open_date/status + current posted hours |
| `recommendation_inputs.json` | per-store bundle keyed by `store_id` — designed to JOIN with the Maps output |
| `summary.xlsx` | Summary sheet + one hour×day_type sheet per store (navy header) |
| `raw/` | persisted live-query JSON + per-store checkpoints; Q1 verified lossless vs control totals |
| `run.log` | schema-resolution report, integrity check, flags |

## Metric definitions
- **opening_pressure** = orders in the posted open hour ÷ mean orders in mid-day hours (12–14). `closing_pressure` = orders in the last posted open hour ÷ same mid-day baseline. `>1` = above-typical demand at that edge.
- **pct_before_open / pct_after_close** = share of orders landing in local hours before posted open / at-or-after posted close.
- **confidence**: `low` if opened <8 weeks before window end, <8 weeks covered, or <100 orders/day; `medium` if <12 weeks; else `high`.

## IMPORTANT caveat for the recommendation step
`pct_before_open` and `pct_after_close` are **≈0 for every store**, and first/last-order
p50 sit right on the posted open/close. This is almost certainly because the **app blocks
ordering outside posted business hours** — so latent demand *before open* or *after close*
is structurally unobservable from order data alone. Internal data tells you the shape and
the in-window edges; whether to **extend** hours must be driven by the competitor-hours
(Maps) signal + `closing_pressure` / late-order p90 (how hard demand is still running at
close). Treat the internal extract as the "current demand within current hours" half of the
join, not as evidence that current hours are already optimal.

## Notes
- `pay_time` (paid/settled time) used as the demand timestamp; successful = `status IN (20,90)`.
- Channel left as numeric codes (no dictionary table found): ch2≈84% (dominant), ch1, ch3, other.
- Labor/shift table (`t_attendance_shift`) exists but has no wage/cost data → labor cost-per-hour skipped (not fabricated).
- DB connection: env-var direct-driver path (`DB_ENGINE`/`SF_*`) was unset, so the project's
  documented live read-only gateway was used instead; results are 100% live, not hardcoded.
